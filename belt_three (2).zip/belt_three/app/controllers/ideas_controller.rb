class IdeasController < ApplicationController

	def bright_ideas
		@user = current_user
		@idea = Idea.all
	end

	def show
		redirect_to '/bright_ideas'

	end

	def create
    @user = current_user
    @idea = Idea.new idea_params
    if @idea.save
      redirect_to "/bright_ideas"
    else
      flash[:errors] = @idea.errors.full_messages
       redirect_to :back
    end
  end



	def idea_page
	@people = Like.where(idea: Idea.find(params[:idea_id])).joins(:user).select("name, alias, user_id")
  	@idea = Idea.find(params[:idea_id])
  	@user = current_user
	puts "66666666666666666666666666666666666666"
	puts "the idea id", @idea
  	render '/ideas/idea_page'
  end

 # def destroy
 #    @user = current_user
 #    @idea = Idea.find(params[:id])
 #    if @idea.user === current_user
 #      @idea.destroy
 #      redirect_to "/bright_ideas"
 #    else
 #      flash[:errors] = @idea.errors.full_messages
 #      redirect_to :back
 #    end
 #  end

private
    def idea_params
      params.require(:idea).permit(:content).merge(user: current_user)
    end
end