Rails.application.routes.draw do
  root 'users#main'
  post '/register' => 'users#create'
  post '/login' => 'sessions#create'
 
  delete '/sessions/:id' => 'sessions#destroy'
  post "/ideas" => 'ideas#create'
  post "users/:id" => 'users#show'
  post '/likes' => 'likes#create'
  get 'users/:id' => 'users#show'
  post 'go_back' => 'users'


  post 'bright_ideas/:idea_id' => 'ideas#idea_page'
  get 'bright_ideas/:idea_id' => 'ideas#idea_page'
  get 'go_back/:id' => 'ideas#show'

  

  get 'bright_ideas' => 'ideas#bright_ideas'
  
  
end
